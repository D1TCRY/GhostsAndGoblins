from .platform import Platform
from .grave_stone import GraveStone
from .ladder import Ladder
from .flame import Flame
from .door import Door