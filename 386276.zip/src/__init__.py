from .g2d_lib import g2d
from .game import *